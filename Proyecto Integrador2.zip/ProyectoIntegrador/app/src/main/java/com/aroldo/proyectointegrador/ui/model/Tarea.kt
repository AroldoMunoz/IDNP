package com.aroldo.proyectointegrador.ui.model

data class Tarea(
    val id: Int,
    val titulo: String,
    val categoria: String,
    val completada: Boolean = false
)