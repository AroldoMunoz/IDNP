package com.aroldo.proyectointegrador.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.aroldo.proyectointegrador.ui.model.Usuario
import com.aroldo.proyectointegrador.ui.navigation.Routes

@Composable
fun BottomBar(
    navController: NavHostController,
    usuario: Usuario?
) {

    val items = listOf(
        Routes.INICIO,
        Routes.PANEL,
        Routes.TAREAS,
        Routes.ESTADISTICAS,
        Routes.PERFIL
    )

    val currentRoute =
        navController.currentBackStackEntryAsState().value
            ?.destination?.route

    NavigationBar {

        items.forEach { route ->

            NavigationBarItem(
                selected = currentRoute == route,

                onClick = {

                    if (currentRoute == route) return@NavigationBarItem

                    navController.navigate(route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                },

                icon = {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = route
                    )
                },

                label = {
                    Text(route)
                }
            )
        }
    }
}