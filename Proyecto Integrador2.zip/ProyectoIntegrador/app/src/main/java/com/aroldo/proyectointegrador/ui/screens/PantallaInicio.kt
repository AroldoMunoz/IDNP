package com.aroldo.proyectointegrador.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aroldo.proyectointegrador.ui.model.Usuario

@Composable
fun PantallaInicio(
    onLogin: (Usuario) -> Unit
) {

    var nombre by rememberSaveable { mutableStateOf("") }
    var correo by rememberSaveable { mutableStateOf("") }
    var edad by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    val habilitado = nombre.isNotBlank() &&
            correo.isNotBlank() &&
            edad.isNotBlank()

    fun validarCorreo(c: String): Boolean {
        return c.contains("@") && c.contains(".")
    }

    fun validarEdad(e: String): Boolean {
        val num = e.toIntOrNull()
        return num != null && num in 1..120
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text("Inicio de Sesión",
        color = MaterialTheme.colorScheme.primary,
        style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = nombre,
            onValueChange = {
                nombre = it
                error = ""
            },
            label = { Text("Nombre") },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = correo,
            onValueChange = {
                correo = it
                error = ""
            },
            label = { Text("Correo") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = edad,
            onValueChange = {
                edad = it
                error = ""
            },
            label = { Text("Edad") }
        )

        if (error.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {

                when {
                    !habilitado -> {
                        error = "Completa todos los campos"
                    }

                    !validarCorreo(correo) -> {
                        error = "Correo inválido"
                    }

                    !validarEdad(edad) -> {
                        error = "Edad inválida"
                    }

                    else -> {
                        onLogin(
                            Usuario(nombre, correo, edad)
                        )
                    }
                }
            },
            enabled = habilitado,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Text("Ingresar")
        }
    }
}