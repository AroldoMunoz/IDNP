package com.aroldo.proyectointegrador.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.aroldo.proyectointegrador.ui.model.Usuario
import com.aroldo.proyectointegrador.ui.navigation.Routes

@Composable
fun PantallaPanel(
    navController: NavController,
    usuario: Usuario?,
    cerrarSesion: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Bienvenido ${usuario?.nombre ?: ""}",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                navController.navigate(Routes.PERFIL)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ver Perfil")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                navController.navigate(Routes.TAREAS)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Mis Tareas")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                navController.navigate(Routes.ESTADISTICAS)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Estadísticas")
        }

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedButton(
            onClick = cerrarSesion,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cerrar Sesión")
        }
    }
}