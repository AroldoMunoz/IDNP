package com.aroldo.proyectointegrador.ui.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class EstadisticasViewModel : ViewModel() {

    private val _progreso = MutableStateFlow(65f)

    val progreso: StateFlow<Float> =
        _progreso.asStateFlow()
}