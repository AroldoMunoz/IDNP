package com.aroldo.proyectointegrador.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import androidx.compose.runtime.saveable.rememberSaveable
import com.aroldo.proyectointegrador.ui.components.BottomBar
import com.aroldo.proyectointegrador.ui.model.Usuario
import com.aroldo.proyectointegrador.ui.screens.*


object Routes {
    const val INICIO = "inicio"
    const val PANEL = "panel"
    const val PERFIL = "perfil"
    const val TAREAS = "tareas"
    const val ESTADISTICAS = "estadisticas"
}

@Composable
fun AppNavigation() {

    val navController = rememberNavController()

    var usuario by rememberSaveable {
        mutableStateOf<Usuario?>(null)
    }

    Scaffold(
        bottomBar = {
            BottomBar(
                navController = navController,
                usuario = usuario
            )
        }
    ) { paddingValues ->

        NavHost(
            navController = navController,
            startDestination = Routes.INICIO,
            modifier = Modifier.padding(paddingValues)
        ) {

            // INICIO
            composable(Routes.INICIO) {

                PantallaInicio(
                    onLogin = { nuevoUsuario ->

                        usuario = nuevoUsuario

                        navController.navigate(Routes.PANEL) {
                            popUpTo(Routes.INICIO)
                        }
                    }
                )
            }

            // PANEL
            composable(Routes.PANEL) {

                PantallaPanel(
                    navController = navController,
                    usuario = usuario,
                    cerrarSesion = {

                        usuario = null

                        navController.navigate(Routes.INICIO) {
                            popUpTo(0)
                        }
                    }
                )
            }

            // PERFIL
            composable(Routes.PERFIL) {

                PantallaPerfil(
                    usuario = usuario,
                    onVolver = {
                        navController.popBackStack()
                    }
                )
            }

            // TAREAS
            composable(Routes.TAREAS) {

                PantallaTareas(
                    onVolver = {
                        navController.popBackStack()
                    }
                )
            }

            composable(Routes.ESTADISTICAS) {

                PantallaEstadisticas(
                    onVolver = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}