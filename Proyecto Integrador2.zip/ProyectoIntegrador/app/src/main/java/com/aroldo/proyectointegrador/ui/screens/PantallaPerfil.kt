package com.aroldo.proyectointegrador.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aroldo.proyectointegrador.ui.model.Usuario

@Composable
fun PantallaPerfil(
    usuario: Usuario?,
    onVolver: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "Perfil",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text("Nombre: ${usuario?.nombre ?: ""}")
        Text("Correo: ${usuario?.correo ?: ""}")
        Text("Edad: ${usuario?.edad ?: ""}")

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onVolver,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Volver")
        }
    }
}