package com.aroldo.proyectointegrador.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.aroldo.proyectointegrador.ui.model.Tarea
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TareasViewModel : ViewModel() {

    private val listaOriginal = listOf(
        Tarea(1, "Estudiar Kotlin", "Estudio"),
        Tarea(2, "Leer documentación", "Estudio"),
        Tarea(3, "Diseñar interfaz", "Trabajo"),
        Tarea(4, "Corregir errores", "Trabajo"),
        Tarea(5, "Preparar exposición", "Estudio"),
        Tarea(6, "Crear informe", "Trabajo"),
        Tarea(7, "Practicar Compose", "Estudio"),
        Tarea(8, "Actualizar README", "Trabajo"),
        Tarea(9, "Probar aplicación", "Trabajo"),
        Tarea(10, "Subir proyecto", "Estudio")
    )

    private val _tareas = MutableStateFlow(listaOriginal)
    val tareas: StateFlow<List<Tarea>> = _tareas.asStateFlow()

    fun eliminarTarea(tarea: Tarea) {

        _tareas.value =
            _tareas.value.filter { it.id != tarea.id }
    }

    fun restaurarTarea(tarea: Tarea) {

        _tareas.value =
            (_tareas.value + tarea)
                .sortedBy { it.id }
    }

    fun filtrar(texto: String) {
        _tareas.value =
            if (texto.isBlank()) {
                listaOriginal
            } else {
                listaOriginal.filter {
                    it.titulo.contains(texto, true)
                }
            }
    }

    fun filtrarCategoria(categoria: String) {
        _tareas.value =
            if (categoria == "Todos") {
                listaOriginal
            } else {
                listaOriginal.filter {
                    it.categoria == categoria
                }
            }
    }
    fun agregarTarea(titulo: String) {

        if (titulo.isBlank()) return

        val nuevoId =
            (_tareas.value.maxOfOrNull { it.id } ?: 0) + 1

        val nuevaTarea = Tarea(
            id = nuevoId,
            titulo = titulo,
            categoria = "General"
        )

        _tareas.value = _tareas.value + nuevaTarea
    }

}