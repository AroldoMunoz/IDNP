package com.aroldo.proyectointegrador.ui.model

data class Usuario(
    val nombre: String,
    val correo: String,
    val edad: String
)