package com.aroldo.proyectointegrador

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.aroldo.proyectointegrador.ui.navigation.AppNavigation
import com.aroldo.proyectointegrador.ui.theme.ProyectoIntegradorTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            ProyectoIntegradorTheme {
                AppNavigation()
            }
        }
    }
}