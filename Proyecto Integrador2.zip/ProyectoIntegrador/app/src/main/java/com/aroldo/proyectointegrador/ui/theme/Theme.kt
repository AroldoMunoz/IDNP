package com.aroldo.proyectointegrador.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF8A50),   // naranja cálido
    secondary = Color(0xFFFFB74D), // ámbar suave
    tertiary = Color(0xFFFF6F61)   // rojo coral cálido
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF4A90E2),   // azul calmado
    secondary = Color(0xFF7BC7B5), // verde suave
    tertiary = Color(0xFF8AB6FF)   // celeste suave
)

@Composable
fun ProyectoIntegradorTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {

    val colorScheme =
        if (darkTheme) {
            DarkColorScheme
        } else {
            LightColorScheme
        }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}