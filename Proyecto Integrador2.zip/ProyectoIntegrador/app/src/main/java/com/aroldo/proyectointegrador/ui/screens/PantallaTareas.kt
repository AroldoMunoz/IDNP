package com.aroldo.proyectointegrador.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aroldo.proyectointegrador.ui.viewmodel.TareasViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaTareas(
    onVolver: () -> Unit,
    viewModel: TareasViewModel = viewModel()
) {

    val tareas by viewModel.tareas.collectAsState()

    var textoTarea by remember { mutableStateOf("") }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(

        snackbarHost = {
            SnackbarHost(snackbarHostState)
        },

        topBar = {
            TopAppBar(
                title = {
                    Text("Gestor de Tareas")
                },
                actions = {
                    IconButton(onClick = { }) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Configuración"
                        )
                    }
                }
            )
        },

        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (textoTarea.isNotBlank()) {
                        viewModel.agregarTarea(textoTarea)
                        textoTarea = ""
                    }
                }
            ) {
                Text("+")
            }
        }

    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(8.dp)
        ) {

            Text(
                text = "Mis Tareas",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(12.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = "Resumen",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Text(
                        text = "Total: ${tareas.size}"
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = textoTarea,
                onValueChange = {
                    textoTarea = it
                    viewModel.filtrar(it)
                },
                label = {
                    Text("Buscar o agregar tarea")
                },
                trailingIcon = {

                    Row {

                        TextButton(
                            onClick = {
                                viewModel.filtrar(textoTarea)
                            }
                        ) {
                            Text("Buscar")
                        }

                        TextButton(
                            onClick = {
                                if (textoTarea.isNotBlank()) {
                                    viewModel.agregarTarea(textoTarea)
                                    textoTarea = ""
                                }
                            }
                        ) {
                            Text("+")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                item {
                    AssistChip(
                        onClick = {
                            viewModel.filtrarCategoria("Todos")
                        },
                        label = {
                            Text("Todos")
                        }
                    )
                }

                item {
                    AssistChip(
                        onClick = {
                            viewModel.filtrarCategoria("Estudio")
                        },
                        label = {
                            Text("📚 Estudio")
                        }
                    )
                }

                item {
                    AssistChip(
                        onClick = {
                            viewModel.filtrarCategoria("Trabajo")
                        },
                        label = {
                            Text("💼 Trabajo")
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (tareas.isEmpty()) {

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "📋 No hay tareas disponibles",
                        style = MaterialTheme.typography.titleLarge
                    )
                }

            } else {

                LazyColumn(
                    modifier = Modifier.weight(1f)
                ) {

                    items(
                        items = tareas,
                        key = { it.id }
                    ) { tarea ->

                        val dismissState = rememberSwipeToDismissBoxState(
                            confirmValueChange = { value ->

                                if (value ==
                                    SwipeToDismissBoxValue.EndToStart
                                ) {

                                    scope.launch {

                                        viewModel.eliminarTarea(tarea)

                                        val result =
                                            snackbarHostState.showSnackbar(
                                                message = "Tarea eliminada",
                                                actionLabel = "Deshacer"
                                            )

                                        if (
                                            result ==
                                            SnackbarResult.ActionPerformed
                                        ) {
                                            viewModel.restaurarTarea(tarea)
                                        }
                                    }

                                    true
                                } else {
                                    false
                                }
                            }
                        )

                        SwipeToDismissBox(
                            state = dismissState,
                            enableDismissFromStartToEnd = false,
                            enableDismissFromEndToStart = true,

                            backgroundContent = {

                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Gray)
                                        .padding(horizontal = 20.dp),
                                    contentAlignment = Alignment.CenterEnd
                                ) {

                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = null,
                                        tint = Color.White
                                    )
                                }
                            }
                        ) {

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),

                                elevation = CardDefaults.cardElevation(
                                    defaultElevation = 6.dp
                                ),

                                colors = CardDefaults.cardColors(
                                    containerColor =
                                    MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {

                                ListItem(

                                    headlineContent = {
                                        Text(
                                            text = tarea.titulo
                                        )
                                    },

                                    supportingContent = {
                                        Text(
                                            text = tarea.categoria
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onVolver,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text("Volver")
            }
        }
    }
}