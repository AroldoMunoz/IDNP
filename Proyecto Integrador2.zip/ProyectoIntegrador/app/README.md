# 📱 App de Visualización y Gestión — Material Design 3 (Unidad 2)

## 📌 Información del proyecto

**Asignatura:** Introducción al Desarrollo de Nuevas Plataformas  
**Unidad:** 2 — Interfaces Avanzadas, Gráficos y Listas  
**Tipo:** Proyecto Integrador  
**Tecnologías:** Jetpack Compose, Material Design 3, ViewModel, StateFlow, Canvas  
**Lenguaje:** Kotlin  
**Plataforma:** Android Studio

---

## 🎯 Descripción general

Este proyecto es la evolución de la aplicación desarrollada en la Unidad 1.  
En esta segunda entrega se han incorporado mejoras importantes en la arquitectura, diseño visual y funcionalidad, aplicando conceptos avanzados de desarrollo Android moderno.

La aplicación permite visualizar y gestionar información dinámica mediante listas interactivas, gráficos personalizados y una interfaz basada en Material Design 3 con soporte para modo claro y oscuro.

---

## 🚀 Funcionalidades principales

### 🎨 1. Interfaz con Material Design 3
- Tema personalizado con `lightColorScheme` y `darkColorScheme`.
- Cambio automático de tema según el sistema:
  ```kotlin
  isSystemInDarkTheme()